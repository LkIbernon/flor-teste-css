# Flowers

> Neste projeto foi criado flores utilizando somente css.

<img src="flores.png" alt="exemplo imagem">

Copyright © 2023 - [Fernandeezz](https://github.com/Fernandeezz)

A permissão é concedida, gratuitamente, a qualquer pessoa que obtenha uma cópia deste arquivo, com restrição de publicar como seu repositório. Porém, sem restrição nos direitos de usar, copiar, modificar e mesclar.
